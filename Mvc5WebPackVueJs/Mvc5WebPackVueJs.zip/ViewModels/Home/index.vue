﻿<template>
    <h1>{{ msg }}aaaaa</h1>
</template>

<script>
    export default {
        //name: 'index',
        data() {
            return {
                msg: 'Welcome to Your Vue.js App'
            }
        }
    }
</script>