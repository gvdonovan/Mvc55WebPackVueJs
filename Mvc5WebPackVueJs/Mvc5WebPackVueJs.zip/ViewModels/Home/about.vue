﻿<template>
    <h1>{{ msg }}</h1>
</template>

<script>
    export default {        
        data() {
            return {
                msg: 'About from Vue.js'
            }
        }
    }
</script>