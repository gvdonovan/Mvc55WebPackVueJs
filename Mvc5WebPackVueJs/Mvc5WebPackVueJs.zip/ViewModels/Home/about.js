﻿import Vue from 'vue'
import App from './about.vue'

new Vue({
    el: '#app',
    render: h => h(App)
})